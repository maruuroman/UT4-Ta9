import { useState, useEffect } from 'react';
import './App.css';

function App() {
  const [count, setCount] = useState(0);

  // Utiliza useEffect para actualizar el título del documento cuando el contador cambia
  useEffect(() => {
    document.title = `Contador: ${count}`; // Actualiza el título del documento
  }, [count]); // El efecto se ejecutará cada vez que cambie el valor de count

  return (
    <>
      <h1>Aumento + Decremento</h1>
      <div className="card">
        <button onClick={() => setCount((count) => count + 1)}>
          Aumento
        </button>
        <button onClick={() => setCount((count) => count - 1)}>
          Decremento
        </button>
        <p>{count}</p>
      </div>
    </>
  );
}

export default App;
